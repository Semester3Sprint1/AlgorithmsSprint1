--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3
-- Dumped by pg_dump version 14.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "SpyGames";
--
-- Name: SpyGames; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "SpyGames" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE "SpyGames" OWNER TO postgres;

\connect "SpyGames"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Agent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Agent" (
    agent_id integer NOT NULL,
    agent_first character varying(35) NOT NULL,
    agent_last character varying(40) NOT NULL,
    code_name character varying(40) NOT NULL
);


ALTER TABLE public."Agent" OWNER TO postgres;

--
-- Name: Agent_agent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Agent_agent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Agent_agent_id_seq" OWNER TO postgres;

--
-- Name: Agent_agent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Agent_agent_id_seq" OWNED BY public."Agent".agent_id;


--
-- Name: Que; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Que" (
    que_id integer NOT NULL,
    "Qmessage" character varying NOT NULL,
    agent_id integer NOT NULL
);


ALTER TABLE public."Que" OWNER TO postgres;

--
-- Name: Que_que_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Que_que_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Que_que_id_seq" OWNER TO postgres;

--
-- Name: Que_que_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Que_que_id_seq" OWNED BY public."Que".que_id;


--
-- Name: Stack; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Stack" (
    stack_id integer NOT NULL,
    "Smessage" character varying NOT NULL,
    agent_id integer NOT NULL
);


ALTER TABLE public."Stack" OWNER TO postgres;

--
-- Name: Stack_stack_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Stack_stack_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Stack_stack_id_seq" OWNER TO postgres;

--
-- Name: Stack_stack_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Stack_stack_id_seq" OWNED BY public."Stack".stack_id;


--
-- Name: Agent agent_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Agent" ALTER COLUMN agent_id SET DEFAULT nextval('public."Agent_agent_id_seq"'::regclass);


--
-- Name: Que que_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Que" ALTER COLUMN que_id SET DEFAULT nextval('public."Que_que_id_seq"'::regclass);


--
-- Name: Stack stack_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Stack" ALTER COLUMN stack_id SET DEFAULT nextval('public."Stack_stack_id_seq"'::regclass);


--
-- Data for Name: Agent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Agent" (agent_id, agent_first, agent_last, code_name) FROM stdin;
\.
COPY public."Agent" (agent_id, agent_first, agent_last, code_name) FROM '$$PATH$$/3589.dat';

--
-- Data for Name: Que; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Que" (que_id, "Qmessage", agent_id) FROM stdin;
\.
COPY public."Que" (que_id, "Qmessage", agent_id) FROM '$$PATH$$/3593.dat';

--
-- Data for Name: Stack; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Stack" (stack_id, "Smessage", agent_id) FROM stdin;
\.
COPY public."Stack" (stack_id, "Smessage", agent_id) FROM '$$PATH$$/3591.dat';

--
-- Name: Agent_agent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Agent_agent_id_seq"', 1, false);


--
-- Name: Que_que_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Que_que_id_seq"', 9, true);


--
-- Name: Stack_stack_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Stack_stack_id_seq"', 2, true);


--
-- Name: Agent Agent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Agent"
    ADD CONSTRAINT "Agent_pkey" PRIMARY KEY (agent_id);


--
-- Name: Que Que_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Que"
    ADD CONSTRAINT "Que_pkey" PRIMARY KEY (que_id);


--
-- Name: Stack Stack_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Stack"
    ADD CONSTRAINT "Stack_pkey" PRIMARY KEY (stack_id);


--
-- PostgreSQL database dump complete
--

